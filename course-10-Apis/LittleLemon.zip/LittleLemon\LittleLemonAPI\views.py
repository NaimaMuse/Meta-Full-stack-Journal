from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User, Group
from django.shortcuts import get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.pagination import PageNumberPagination

from .models import Category, MenuItem, Cart, Order, OrderItem
from .serializers import (
    CategorySerializer,
    MenuItemSerializer,
    UserSerializer,
    CartSerializer,
    OrderSerializer,
)
from .permissions import IsManager, IsDeliveryCrew, IsManagerOrReadOnly


class StandardResultsSetPagination(PageNumberPagination):
    page_size = 5
    page_size_query_param = 'perpage'
    max_page_size = 50


# ==============================================================================
# Category Views
# ==============================================================================
class CategoryListView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsManagerOrReadOnly]


class CategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsManagerOrReadOnly]


# ==============================================================================
# Menu Items Views
# ==============================================================================
class MenuItemListView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.select_related('category').all()
    serializer_class = MenuItemSerializer
    pagination_class = StandardResultsSetPagination
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['title', 'category__title']
    ordering_fields = ['price', 'title']

    def get_permissions(self):
        if self.request.method in ['POST']:
            return [IsManager()]
        return []

    def get_queryset(self):
        queryset = super().get_queryset()
        category_param = self.request.query_params.get('category')
        to_price = self.request.query_params.get('to_price')
        from_price = self.request.query_params.get('from_price')
        featured = self.request.query_params.get('featured')

        if category_param:
            if category_param.isdigit():
                queryset = queryset.filter(category_id=category_param)
            else:
                queryset = queryset.filter(category__slug=category_param) | queryset.filter(category__title__iexact=category_param)
        if to_price:
            queryset = queryset.filter(price__lte=to_price)
        if from_price:
            queryset = queryset.filter(price__gte=from_price)
        if featured is not None:
            if featured.lower() in ['true', '1']:
                queryset = queryset.filter(featured=True)
            elif featured.lower() in ['false', '0']:
                queryset = queryset.filter(featured=False)

        return queryset


class MenuItemDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.select_related('category').all()
    serializer_class = MenuItemSerializer

    def get_permissions(self):
        if self.request.method in ['PUT', 'PATCH', 'DELETE']:
            return [IsManager()]
        return []


# ==============================================================================
# User Group Management Views
# ==============================================================================
class ManagerUserListView(APIView):
    permission_classes = [IsManager]

    def get(self, request):
        manager_group, _ = Group.objects.get_or_create(name='Manager')
        managers = manager_group.user_set.all()
        serializer = UserSerializer(managers, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        username = request.data.get('username')
        if not username:
            return Response({'message': 'Username is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = get_object_or_404(User, username=username)
        manager_group, _ = Group.objects.get_or_create(name='Manager')
        manager_group.user_set.add(user)
        return Response({'message': 'user added to the manager group'}, status=status.HTTP_201_CREATED)


class ManagerUserDetailView(APIView):
    permission_classes = [IsManager]

    def delete(self, request, userId):
        user = get_object_or_404(User, id=userId)
        manager_group = get_object_or_404(Group, name='Manager')
        if user not in manager_group.user_set.all():
            return Response({'message': 'User is not in the manager group'}, status=status.HTTP_404_NOT_FOUND)
        
        manager_group.user_set.remove(user)
        return Response({'message': 'user removed from the manager group'}, status=status.HTTP_200_OK)


class DeliveryCrewUserListView(APIView):
    permission_classes = [IsManager]

    def get(self, request):
        crew_group, _ = Group.objects.get_or_create(name='Delivery crew')
        crew_members = crew_group.user_set.all()
        serializer = UserSerializer(crew_members, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        username = request.data.get('username')
        if not username:
            return Response({'message': 'Username is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = get_object_or_404(User, username=username)
        crew_group, _ = Group.objects.get_or_create(name='Delivery crew')
        crew_group.user_set.add(user)
        return Response({'message': 'user added to the delivery crew group'}, status=status.HTTP_201_CREATED)


class DeliveryCrewUserDetailView(APIView):
    permission_classes = [IsManager]

    def delete(self, request, userId):
        user = get_object_or_404(User, id=userId)
        crew_group = get_object_or_404(Group, name='Delivery crew')
        if user not in crew_group.user_set.all():
            return Response({'message': 'User is not in the delivery crew group'}, status=status.HTTP_404_NOT_FOUND)
        
        crew_group.user_set.remove(user)
        return Response({'message': 'user removed from the delivery crew group'}, status=status.HTTP_200_OK)


# ==============================================================================
# Cart Management Views
# ==============================================================================
class CartItemListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        cart_items = Cart.objects.filter(user=request.user)
        serializer = CartSerializer(cart_items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = CartSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        Cart.objects.filter(user=request.user).delete()
        return Response({'message': 'All items removed from cart'}, status=status.HTTP_200_OK)


# ==============================================================================
# Order Management Views
# ==============================================================================
class OrderListView(generics.ListCreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['status', 'delivery_crew', 'date']
    ordering_fields = ['total', 'date', 'status']

    def get_queryset(self):
        user = self.request.user
        if user.is_superuser or user.is_staff or user.groups.filter(name='Manager').exists():
            return Order.objects.prefetch_related('order_items').all()
        elif user.groups.filter(name='Delivery crew').exists():
            return Order.objects.prefetch_related('order_items').filter(delivery_crew=user)
        else:
            return Order.objects.prefetch_related('order_items').filter(user=user)

    def create(self, request, *args, **kwargs):
        cart_items = Cart.objects.filter(user=request.user)
        if not cart_items.exists():
            return Response({'message': 'Cart is empty'}, status=status.HTTP_400_BAD_REQUEST)

        total = sum([item.price for item in cart_items])
        order = Order.objects.create(user=request.user, total=total, status=False)

        order_items = [
            OrderItem(
                order=order,
                menuitem=item.menuitem,
                quantity=item.quantity,
                unit_price=item.unit_price,
                price=item.price,
            )
            for item in cart_items
        ]
        OrderItem.objects.bulk_create(order_items)
        cart_items.delete()

        serializer = OrderSerializer(order)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class OrderDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        return get_object_or_404(Order.objects.prefetch_related('order_items'), pk=pk)

    def get(self, request, pk):
        order = self.get_object(pk)
        user = request.user
        is_manager = user.is_superuser or user.is_staff or user.groups.filter(name='Manager').exists()
        is_delivery = user.groups.filter(name='Delivery crew').exists()

        if is_manager:
            serializer = OrderSerializer(order)
            return Response(serializer.data, status=status.HTTP_200_OK)
        elif is_delivery and order.delivery_crew == user:
            serializer = OrderSerializer(order)
            return Response(serializer.data, status=status.HTTP_200_OK)
        elif order.user == user:
            serializer = OrderSerializer(order)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'You do not have access to this order'}, status=status.HTTP_403_FORBIDDEN)

    def put(self, request, pk):
        order = self.get_object(pk)
        user = request.user
        is_manager = user.is_superuser or user.is_staff or user.groups.filter(name='Manager').exists()

        if not is_manager:
            return Response({'message': 'Forbidden'}, status=status.HTTP_403_FORBIDDEN)

        serializer = OrderSerializer(order, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk):
        order = self.get_object(pk)
        user = request.user
        is_manager = user.is_superuser or user.is_staff or user.groups.filter(name='Manager').exists()
        is_delivery = user.groups.filter(name='Delivery crew').exists()

        if is_manager:
            delivery_crew_id = request.data.get('delivery_crew')
            order_status = request.data.get('status')

            if delivery_crew_id is not None:
                if delivery_crew_id == "" or delivery_crew_id is None:
                    order.delivery_crew = None
                else:
                    crew_user = get_object_or_404(User, id=delivery_crew_id)
                    crew_group = get_object_or_404(Group, name='Delivery crew')
                    if crew_user not in crew_group.user_set.all():
                        return Response(
                            {'message': 'User is not in the delivery crew group'},
                            status=status.HTTP_400_BAD_REQUEST
                        )
                    order.delivery_crew = crew_user

            if order_status is not None:
                order.status = bool(int(order_status)) if isinstance(order_status, (int, str)) and str(order_status).isdigit() else bool(order_status)

            order.save()
            serializer = OrderSerializer(order)
            return Response(serializer.data, status=status.HTTP_200_OK)

        elif is_delivery:
            if order.delivery_crew != user:
                return Response({'message': 'Forbidden'}, status=status.HTTP_403_FORBIDDEN)
            
            order_status = request.data.get('status')
            if order_status is None:
                return Response({'message': 'Status field is required'}, status=status.HTTP_400_BAD_REQUEST)
            
            order.status = bool(int(order_status)) if isinstance(order_status, (int, str)) and str(order_status).isdigit() else bool(order_status)
            order.save()
            serializer = OrderSerializer(order)
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response({'message': 'Forbidden'}, status=status.HTTP_403_FORBIDDEN)

    def delete(self, request, pk):
        order = self.get_object(pk)
        user = request.user
        is_manager = user.is_superuser or user.is_staff or user.groups.filter(name='Manager').exists()

        if not is_manager:
            return Response({'message': 'Forbidden'}, status=status.HTTP_403_FORBIDDEN)

        order.delete()
        return Response({'message': 'Order deleted successfully'}, status=status.HTTP_200_OK)
