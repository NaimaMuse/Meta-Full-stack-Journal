from django.urls import path
from . import views

urlpatterns = [
    # Categories
    path('categories', views.CategoryListView.as_view(), name='category-list'),
    path('categories/<int:pk>', views.CategoryDetailView.as_view(), name='category-detail'),

    # Menu Items
    path('menu-items', views.MenuItemListView.as_view(), name='menuitem-list'),
    path('menu-items/<int:pk>', views.MenuItemDetailView.as_view(), name='menuitem-detail'),

    # Manager User Group Management
    path('groups/manager/users', views.ManagerUserListView.as_view(), name='manager-users-list'),
    path('groups/manager/users/<int:userId>', views.ManagerUserDetailView.as_view(), name='manager-user-detail'),

    # Delivery Crew User Group Management
    path('groups/delivery-crew/users', views.DeliveryCrewUserListView.as_view(), name='delivery-crew-users-list'),
    path('groups/delivery-crew/users/<int:userId>', views.DeliveryCrewUserDetailView.as_view(), name='delivery-crew-user-detail'),

    # Cart Management
    path('cart/menu-items', views.CartItemListView.as_view(), name='cart-items'),

    # Order Management
    path('orders', views.OrderListView.as_view(), name='order-list'),
    path('orders/<int:pk>', views.OrderDetailView.as_view(), name='order-detail'),
]
