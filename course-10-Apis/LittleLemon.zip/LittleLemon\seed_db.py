import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'LittleLemon.settings')
django.setup()

from django.contrib.auth.models import User, Group
from rest_framework.authtoken.models import Token
from LittleLemonAPI.models import Category, MenuItem

def seed():
    print("Seeding database...")

    # Create Groups
    manager_group, _ = Group.objects.get_or_create(name='Manager')
    delivery_group, _ = Group.objects.get_or_create(name='Delivery crew')

    # Create Superuser (Admin)
    admin_user, created = User.objects.get_or_create(
        username='admin',
        defaults={'email': 'admin@littlelemon.com', 'is_staff': True, 'is_superuser': True}
    )
    admin_user.set_password('AdminPass123!')
    admin_user.save()
    Token.objects.get_or_create(user=admin_user)

    # Create Manager User
    manager_user, created = User.objects.get_or_create(
        username='manager_john',
        defaults={'email': 'manager@littlelemon.com', 'is_staff': True}
    )
    manager_user.set_password('ManagerPass123!')
    manager_user.save()
    manager_group.user_set.add(manager_user)
    Token.objects.get_or_create(user=manager_user)

    # Create Delivery Crew User
    driver_user, created = User.objects.get_or_create(
        username='driver_mike',
        defaults={'email': 'driver@littlelemon.com'}
    )
    driver_user.set_password('DriverPass123!')
    driver_user.save()
    delivery_group.user_set.add(driver_user)
    Token.objects.get_or_create(user=driver_user)

    # Create Customer User
    customer_user, created = User.objects.get_or_create(
        username='customer_anna',
        defaults={'email': 'anna@example.com'}
    )
    customer_user.set_password('CustomerPass123!')
    customer_user.save()
    Token.objects.get_or_create(user=customer_user)

    # Create Second Customer User
    customer2_user, created = User.objects.get_or_create(
        username='customer_david',
        defaults={'email': 'david@example.com'}
    )
    customer2_user.set_password('CustomerPass123!')
    customer2_user.save()
    Token.objects.get_or_create(user=customer2_user)

    # Create Categories
    appetizers, _ = Category.objects.get_or_create(slug='appetizers', defaults={'title': 'Appetizers'})
    mains, _ = Category.objects.get_or_create(slug='main-dishes', defaults={'title': 'Main Dishes'})
    desserts, _ = Category.objects.get_or_create(slug='desserts', defaults={'title': 'Desserts'})
    drinks, _ = Category.objects.get_or_create(slug='drinks', defaults={'title': 'Drinks'})

    # Create Menu Items
    items = [
        {'title': 'Greek Salad', 'price': 10.00, 'featured': True, 'category': appetizers},
        {'title': 'Bruschetta', 'price': 7.50, 'featured': False, 'category': appetizers},
        {'title': 'Beef Pasta', 'price': 12.00, 'featured': True, 'category': mains},
        {'title': 'Tomato Pasta', 'price': 5.00, 'featured': False, 'category': mains},
        {'title': 'Grilled Salmon', 'price': 18.00, 'featured': False, 'category': mains},
        {'title': 'Lemon Dessert', 'price': 6.50, 'featured': True, 'category': desserts},
        {'title': 'Tiramisu', 'price': 7.00, 'featured': False, 'category': desserts},
        {'title': 'Iced Lemon Tea', 'price': 3.50, 'featured': False, 'category': drinks},
    ]

    for item in items:
        MenuItem.objects.get_or_create(
            title=item['title'],
            defaults={
                'price': item['price'],
                'featured': item['featured'],
                'category': item['category'],
            }
        )

    print("Database successfully seeded!")

if __name__ == '__main__':
    seed()
