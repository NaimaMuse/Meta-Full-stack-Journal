from django.test import TestCase
from django.contrib.auth.models import User, Group
from rest_framework.test import APIClient
from rest_framework import status
from rest_framework.authtoken.models import Token
from .models import Category, MenuItem


class LittleLemonAPITestCase(TestCase):
    def setUp(self):
        self.client = APIClient()

        # Groups
        self.manager_group = Group.objects.create(name='Manager')
        self.delivery_group = Group.objects.create(name='Delivery crew')

        # Admin
        self.admin_user = User.objects.create_superuser(
            username='admin_test', email='admin@test.com', password='password123'
        )
        self.admin_token = Token.objects.create(user=self.admin_user)

        # Manager
        self.manager_user = User.objects.create_user(
            username='manager_test', email='manager@test.com', password='password123'
        )
        self.manager_group.user_set.add(self.manager_user)
        self.manager_token = Token.objects.create(user=self.manager_user)

        # Delivery crew
        self.delivery_user = User.objects.create_user(
            username='delivery_test', email='delivery@test.com', password='password123'
        )
        self.delivery_group.user_set.add(self.delivery_user)
        self.delivery_token = Token.objects.create(user=self.delivery_user)

        # Customer
        self.customer_user = User.objects.create_user(
            username='customer_test', email='customer@test.com', password='password123'
        )
        self.customer_token = Token.objects.create(user=self.customer_user)

        # Candidate user to be assigned to groups
        self.candidate_user = User.objects.create_user(
            username='candidate_user', email='candidate@test.com', password='password123'
        )

        # Categories
        self.cat_appetizers = Category.objects.create(title='Appetizers', slug='appetizers')
        self.cat_mains = Category.objects.create(title='Main Dishes', slug='main-dishes')

        # Menu Items
        self.item_salad = MenuItem.objects.create(
            title='Greek Salad', price=10.00, featured=True, category=self.cat_appetizers
        )
        self.item_pasta = MenuItem.objects.create(
            title='Tomato Pasta', price=5.00, featured=False, category=self.cat_mains
        )
        self.item_salmon = MenuItem.objects.create(
            title='Grilled Salmon', price=18.00, featured=False, category=self.cat_mains
        )

    # 1 & 2. Admin assign user to manager group & access manager group with admin token
    def test_admin_and_manager_group_management(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.admin_token.key)
        
        # Access manager group
        response = self.client.get('/api/groups/manager/users')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Assign user to manager group
        response = self.client.post('/api/groups/manager/users', {'username': 'candidate_user'})
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(self.candidate_user.groups.filter(name='Manager').exists())

        # Remove user from manager group
        response = self.client.delete(f'/api/groups/manager/users/{self.candidate_user.id}')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(self.candidate_user.groups.filter(name='Manager').exists())

    # 3 & 4. Admin / Manager can add categories and menu items
    def test_add_category_and_menu_item(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.manager_token.key)

        # Add Category
        cat_resp = self.client.post('/api/categories', {'title': 'Desserts', 'slug': 'desserts'})
        self.assertEqual(cat_resp.status_code, status.HTTP_201_CREATED)
        cat_id = cat_resp.data['id']

        # Add Menu Item
        item_resp = self.client.post('/api/menu-items', {
            'title': 'Lemon Cake',
            'price': '6.50',
            'featured': True,
            'category': cat_id,
        })
        self.assertEqual(item_resp.status_code, status.HTTP_201_CREATED)

    # 5. Managers can log in and get token
    def test_manager_login(self):
        response = self.client.post('/token/login/', {
            'username': 'manager_test',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('auth_token', response.data)

    # 6. Managers can update the item of the day (featured)
    def test_manager_update_item_of_the_day(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.manager_token.key)
        response = self.client.patch(f'/api/menu-items/{self.item_pasta.id}', {'featured': True})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.item_pasta.refresh_from_db()
        self.assertTrue(self.item_pasta.featured)

    # 7. Managers can assign users to delivery crew
    def test_manager_assign_delivery_crew(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.manager_token.key)
        response = self.client.post('/api/groups/delivery-crew/users', {'username': 'candidate_user'})
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(self.candidate_user.groups.filter(name='Delivery crew').exists())

    # 11 & 12. Customers can register & log in
    def test_customer_registration_and_login(self):
        # Register
        reg_resp = self.client.post('/api/users/', {
            'username': 'new_customer',
            'password': 'StrongPassword123!',
            'email': 'new_customer@example.com'
        })
        self.assertEqual(reg_resp.status_code, status.HTTP_201_CREATED)

        # Login
        login_resp = self.client.post('/token/login/', {
            'username': 'new_customer',
            'password': 'StrongPassword123!'
        })
        self.assertEqual(login_resp.status_code, status.HTTP_200_OK)
        self.assertIn('auth_token', login_resp.data)

    # 13, 14, 15, 16, 17. Browsing, Filtering, Pagination, Sorting
    def test_menu_browsing_filtering_sorting_pagination(self):
        # Browse categories
        cat_resp = self.client.get('/api/categories')
        self.assertEqual(cat_resp.status_code, status.HTTP_200_OK)

        # Browse all menu items
        items_resp = self.client.get('/api/menu-items')
        self.assertEqual(items_resp.status_code, status.HTTP_200_OK)
        self.assertIn('results', items_resp.data)

        # Filter by category
        filter_resp = self.client.get(f'/api/menu-items?category={self.cat_appetizers.slug}')
        self.assertEqual(filter_resp.status_code, status.HTTP_200_OK)
        for item in filter_resp.data['results']:
            self.assertEqual(item['category'], self.cat_appetizers.id)

        # Sort by price
        sort_resp = self.client.get('/api/menu-items?ordering=price')
        self.assertEqual(sort_resp.status_code, status.HTTP_200_OK)
        prices = [float(item['price']) for item in sort_resp.data['results']]
        self.assertEqual(prices, sorted(prices))

        # Pagination
        page_resp = self.client.get('/api/menu-items?perpage=2&page=1')
        self.assertEqual(page_resp.status_code, status.HTTP_200_OK)
        self.assertEqual(len(page_resp.data['results']), 2)

    # 18, 19, 20, 21. Cart management and Order placement / browsing
    def test_customer_cart_and_orders(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.customer_token.key)

        # Add item to cart
        cart_post = self.client.post('/api/cart/menu-items', {
            'menuitem': self.item_salad.id,
            'quantity': 2
        })
        self.assertEqual(cart_post.status_code, status.HTTP_201_CREATED)
        self.assertEqual(float(cart_post.data['price']), 20.00)

        # View cart
        cart_get = self.client.get('/api/cart/menu-items')
        self.assertEqual(cart_get.status_code, status.HTTP_200_OK)
        self.assertEqual(len(cart_get.data), 1)

        # Place order
        order_post = self.client.post('/api/orders')
        self.assertEqual(order_post.status_code, status.HTTP_201_CREATED)
        order_id = order_post.data['id']
        self.assertEqual(float(order_post.data['total']), 20.00)

        # Cart should now be empty
        cart_check = self.client.get('/api/cart/menu-items')
        self.assertEqual(len(cart_check.data), 0)

        # Customer browse own orders
        orders_get = self.client.get('/api/orders')
        self.assertEqual(orders_get.status_code, status.HTTP_200_OK)
        self.assertEqual(orders_get.data['count'], 1)

        # 8. Manager assign order to delivery crew
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.manager_token.key)
        patch_order = self.client.patch(f'/api/orders/{order_id}', {
            'delivery_crew': self.delivery_user.id,
            'status': 0
        })
        self.assertEqual(patch_order.status_code, status.HTTP_200_OK)
        self.assertEqual(patch_order.data['delivery_crew'], self.delivery_user.id)

        # 9. Delivery crew access assigned order
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.delivery_token.key)
        delivery_orders = self.client.get('/api/orders')
        self.assertEqual(delivery_orders.status_code, status.HTTP_200_OK)
        self.assertEqual(delivery_orders.data['count'], 1)

        # 10. Delivery crew update order status as delivered
        delivered_patch = self.client.patch(f'/api/orders/{order_id}', {'status': 1})
        self.assertEqual(delivered_patch.status_code, status.HTTP_200_OK)
        self.assertTrue(delivered_patch.data['status'])

    # Unauthorized access checks
    def test_customer_forbidden_on_manager_endpoints(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.customer_token.key)

        # Customer cannot POST menu item
        resp = self.client.post('/api/menu-items', {
            'title': 'Hacker Dish',
            'price': '99.00',
            'category': self.cat_mains.id
        })
        self.assertEqual(resp.status_code, status.HTTP_403_FORBIDDEN)

        # Customer cannot access group endpoints
        resp = self.client.get('/api/groups/manager/users')
        self.assertEqual(resp.status_code, status.HTTP_403_FORBIDDEN)
