from django.contrib import admin
from django.urls import path, include
from djoser.views import UserViewSet, TokenCreateView, TokenDestroyView

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Little Lemon App APIs
    path('api/', include('LittleLemonAPI.urls')),
    
    # Djoser User registration and management (/api/users/, /api/users/me/, etc.)
    path('api/', include('djoser.urls')),
    
    # Token login/logout at /token/login/ and /token/logout/
    path('token/login/', TokenCreateView.as_view(), name='token_login'),
    path('token/logout/', TokenDestroyView.as_view(), name='token_logout'),
    
    # Token login/logout at /api/token/login/ and /api/token/logout/
    path('api/token/login/', TokenCreateView.as_view(), name='api_token_login'),
    path('api/token/logout/', TokenDestroyView.as_view(), name='api_token_logout'),
    
    # Additional Djoser authtoken support
    path('api/', include('djoser.urls.authtoken')),
    path('auth/', include('djoser.urls')),
    path('auth/', include('djoser.urls.authtoken')),
    
    # Support for nested /api/users/users/me/ alias if requested
    path('api/users/users/me/', UserViewSet.as_view({'get': 'me'}), name='user-me-alias'),
]
